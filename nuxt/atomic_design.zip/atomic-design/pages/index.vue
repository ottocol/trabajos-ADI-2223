<template>
  <div class="container mx-auto mt-10">
    <div>
      <h1>Button Atom</h1>
      <a-button />
      <a-button text="Confirmar" />
      <a-button
        text="Confirmar"
        style-button="bg-green-500 border text-white p-2 rounded-lg"
      />
    </div>

    <div class="mt-10">
      <h1>Input Atom</h1>
      <a-input />
    </div>

    <div class="mt-10">
      <h1>Molecules</h1>
      <m-search-input />
    </div>

    <div class="mt-10">
      <h1>Organisms</h1>
      <o-double-search />
    </div>
  </div>
</template>

<script>
import AButton from '@/components/atoms/AButton.vue'
import AInput from '@/components/atoms/AInput.vue'
import MSearchInput from '@/components/molecules/MSearchInput.vue'
import ODoubleSearch from '@/components/organisms/ODoubleSearch.vue'

export default {
  name: 'Index',
  components: {
    AButton,
    AInput,
    MSearchInput,
    ODoubleSearch,
  },
}
</script>
