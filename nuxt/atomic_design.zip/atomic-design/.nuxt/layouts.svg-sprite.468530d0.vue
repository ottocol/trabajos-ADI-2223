<template>
    <nuxt/>
</template>
