<template>
  <!-- Podemos combinar todos estos átomos y crear estructuras predefinidas para nuestra web. Por ejemplo, en este caso se ha creado el típico input de búsqueda de un listado combinando
el átomo del input junto con el átomo del botón. Este igualmente se podrá reutilizar y modificar si afectar el comportamiento de los propios átomos.-->
  <div class="flex items-center">
    <a-input placeholder="Busca aquí..."></a-input>
    <a-button
      style-button="ml-1 bg-blue-500 border text-white px-2 py-3 rounded-lg"
      text="Buscar"
    >
      <template #icon>
        <svg-icon
          name="search"
          class="w-5 h-5 text-white stroke-current fill-transparent"
        />
      </template>
    </a-button>
  </div>
</template>

<script>
import AButton from '@/components/atoms/AButton.vue'
import AInput from '@/components/atoms/AInput.vue'

export default {
  name: 'MSearchInput',
  components: {
    AButton,
    AInput,
  },
}
</script>
