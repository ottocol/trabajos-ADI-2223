<template>
  <!-- Finalmente somos capaces hasta de combinar estas moléculas para crear estructuras de componentes aún más grandes. Estos componentes están ya pensados para ser grandes apartados
de una misma página (suelen ser los menos reutilizados, pero también nos ofrecen esa posibilidad). En los organismos podemos combinar moléculas con moléculas e incluso átomos u otros 
organismos según necesitemos.-->
  <div>
    <m-search-input />
    <m-search-input />
  </div>
</template>

<script>
import MSearchInput from '@/components/molecules/MSearchInput.vue'

export default {
  name: 'ODoubleSearch',
  components: {
    MSearchInput,
  },
}
</script>
