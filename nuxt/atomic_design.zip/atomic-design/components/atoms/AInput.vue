<template>
  <!-- También somos capaces de crear un input el cual poder reutilizar por todo nuestro proyecto. Como podemos observar abajo, podemos añadir tantos emits como queramos y propagar
los eventos que deseemos para lograr nuestros objetivos. Si realizaramos cualquier cambio en el componente lo recibiríamos en todos los inputs del proyecto.-->
  <input
    :type="type"
    :class="classStyle"
    v-bind="$attrs"
    :value="value"
    :placeholder="placeholder"
    @focus="$emit('focus', $event.target.value)"
    @input="$emit('input', $event.target.value)"
    @change="$emit('change', $event.target.value)"
    @keyup.enter="$emit('keyupEnter', $event.target.value)"
    @blur="$emit('blur', $event.target.value)"
    @keypress="$emit('keypress', $event)"
  />
</template>
<script>
export default {
  name: 'AInput',
  inheritAttrs: false,
  props: {
    value: {
      type: [String, Number],
      default: '',
      required: false,
    },
    placeholder: {
      type: String,
      default: 'Escribe aquí...',
    },
    type: {
      type: String,
      default: 'text',
      validator(value) {
        return [
          'text',
          'password',
          'email',
          'number',
          'tel',
          'search',
        ].includes(value)
      },
    },
    hasErrors: {
      type: Boolean,
      default: false,
    },
    customClass: {
      type: String,
      default:
        'py-3 transition duration-700 ease-in-out outline-none border border-black rounded-lg',
    },
  },
  computed: {
    classStyle() {
      return this.hasErrors
        ? `bg-red-100 placeholder-red-500 ${this.customClass}`
        : this.customClass
    },
  },
}
</script>
