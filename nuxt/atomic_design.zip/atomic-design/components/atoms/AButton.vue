<template>
  <!-- Creamos un boton que contenga props tanto para su estilo como para su texto. De esta forma podemos cambiar su apariencia de manera sencilla
y creando un código limpio y fácilmente mantenible. 
Esta opción nos permite añadir muchísimas funcionalidades a nuestro botón ya sean slots para iconos e incluso propagar nuestro evento click hacia componentes superiores para
lograr el funcionamiento que deseamos-->
  <button class="flex items-center" :class="styleButton" @click="clickButton">
    {{ text }}<slot name="icon"></slot>
  </button>
</template>

<script>
export default {
  name: 'AButton',
  props: {
    styleButton: {
      type: String,
      default: 'bg-blue-500 border text-white p-2 rounded-lg',
    },
    text: {
      type: String,
      default: 'MyButton',
    },
  },
  methods: {
    clickButton() {
      this.$emit('click')
    },
  },
}
</script>
