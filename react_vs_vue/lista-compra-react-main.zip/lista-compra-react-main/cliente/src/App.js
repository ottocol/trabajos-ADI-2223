import './App.css';
import RegistroLogin from './components/RegistroLogin';

function App() {
  return (
    <RegistroLogin />
  );
}

export default App;
