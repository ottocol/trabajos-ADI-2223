import React, { useState, useEffect } from 'react';
import ClienteAPI from '../servicios/ClienteApi';
import './lista.css'

const Lista = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState("");
  const cliente = new ClienteAPI("http://localhost:3000/items");

  useEffect(() => {
    async function fetchData() {
      const datos = await cliente.getItems();
      setItems(datos);
    }
    fetchData();
  }, []);

  const Item = (nombre, comprado, id) => {
    return (
      <div>
        <li>
          <a className={comprado ? 'tachado' : ''}>{nombre}</a>
          <button onClick={() => handleDelete(id)}>Borrar</button>
        </li>
      </div>

    );
  }

  const NewItem = ({ addItem }) => {
    const [nombre, setNombre] = useState("");

    return (

      <div className="centrarNewItem">
        <input value={nombre} placeholder="Nuevo item" onChange={e => setNombre(e.target.value)} />
        <button onClick={() => addItem(nombre)}>Insertar</button>
      </div>

    );
  }

  const handleToggle = async (id) => {
    const item = items.find(x => x.id === id);
    const value = item.comprado ? false : true;
    const resp = await cliente.toggleItem(id, value);
    const updatedDatos = await cliente.getItems();
    setItems(updatedDatos);
  }

  const handleAdd = async (nom) => {
    const resp = await cliente.addItem(nom);
    const updatedDatos = await cliente.getItems();
    setItems(updatedDatos);
  }

  const handleDelete = async (id) => {
    const item = items.find(x => x.id === id);
    const resp = await cliente.delItem(id);
    const updatedDatos = await cliente.getItems();
    setItems(updatedDatos);
  }

  return (
    <div>
      <h1>Lista de la compra</h1>
      <div className='contenido'>
        <ul>
          <NewItem addItem={handleAdd} />
          {items.map(item => (
            <div>
              <li onClick={() =>handleToggle(item.id)}>
                <a className={item.comprado ? 'tachado' : ''}>{item.nombre}</a>
                <button onClick={() => handleDelete(item.id)}>Borrar</button>
              </li>
            </div>
          ))}
        </ul>
      </div>
      
    </div>
  );
}

export default Lista;