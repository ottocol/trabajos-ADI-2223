import React, { useState, useEffect } from 'react';
import ClienteAPI from '../servicios/ClienteApi';
import Lista from './Lista';

import './lista.css'

const RegistroLogin = () => {
  const login = new ClienteAPI("http://localhost:3000/login");
  const registro = new ClienteAPI("http://localhost:3000/register");

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleRegistro = async (username, password) => {
    try {
      const resp = await registro.loginRegistro(username, password);  
      alert(resp.mensaje)
    } catch (error) {
      alert(error.message)
    }
  }

  const handleLogin = async (username, password) => {
    try {
      const resp = await login.loginRegistro(username, password);  
      alert(resp.mensaje)

      document.getElementById('lista').style.display = 'block';
      document.getElementById('loginDiv').style.display = 'none';
      
    } catch (error) {
      alert(error.message)
    }
  }

  const cambiarVista = () => {
    if(document.getElementById("registroDiv").style.display != 'none'){
      document.getElementById("registroDiv").style.display = 'none';
      document.getElementById("loginDiv").style.display = 'block';
    }else{
      document.getElementById("registroDiv").style.display = 'block';
      document.getElementById("loginDiv").style.display = 'none';
    }
  }

  const volverAlLogin = () => {
      document.getElementById("registroDiv").style.display = 'none';
      document.getElementById("loginDiv").style.display = 'block';
      document.getElementById('lista').style.display = 'none';
  }

  return (
    <div>
      <div id="registroDiv" style={{display: 'none'}}>
        <h1>Registro</h1>
        <div className='centrar'>
          <label for="username"> Username </label>
          <input type="text" id="username" value={username} placeholder="Escriba el nombre del usuario" onChange={e => setUsername(e.target.value)}></input>  <br/> <br/>
          <label for="password"> Password </label>
          <input type="password" id="password" value={password} placeholder="Escriba la contraseña" onChange={e => setPassword(e.target.value)}></input >  <br/> <br/>
          <button onClick={() => handleRegistro(username, password)}> Registrarse </button>
          <button onClick={() => cambiarVista()}> Ir a Login </button>
        </div>
      </div>   
      <div id="loginDiv">
        <h1>Login</h1>
        <div className='centrar'>
          <label for="username"> Username </label>
          <input type="text" id="username" value={username} placeholder="Escriba el nombre del usuario" onChange={e => setUsername(e.target.value)}></input>  <br/> <br/>
          <label for="password"> Password </label>
          <input type="password" id="password" value={password} placeholder="Escriba la contraseña" onChange={e => setPassword(e.target.value)}></input >  <br/> <br/>
          <button onClick={() => handleLogin(username, password)}> Login </button>
          <button onClick={() => cambiarVista()}> Ir a Registro </button>
        </div>
      </div>  
      <div id="lista" style={{display: 'none'}}>
        <button onClick={() => volverAlLogin()} style={{height: '50px', width: '200px', marginLeft: '30px', marginTop: '30px'}}> Log out </button>
        <Lista></Lista>
      </div> 
         
    </div>
  );
}

export default RegistroLogin;