# lista-compra-react
ADI Práctica grupal : Lista Compra React ( React vs Vue)
