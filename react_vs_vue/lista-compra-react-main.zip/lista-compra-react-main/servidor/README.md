# Lista de la compra hecha en clase de prácticas 22/09/2020

API "clásico"/No REST

- Como en cualquier proyecto Node, instalar las dependencias con `npm install`
- Ejecutar el servidor con `node index.js` 