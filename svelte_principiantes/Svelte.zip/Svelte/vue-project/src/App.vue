<script>
    import { ref } from 'vue'
    export default {
        setup() {
            const count = ref(0)
            return {
                count
            }
        }
    }
</script>

<template>
  <h1> Vue </h1>
  <button type="button" @click="count++">count is {{ count }}</button>
</template>