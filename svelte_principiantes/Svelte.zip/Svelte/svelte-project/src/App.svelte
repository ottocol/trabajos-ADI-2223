<script>
  let count = 0
</script>

<main>
    <h1> Svelte </h1>
    <button on:click= { () => { count += 1 } }> count is {count} </button>
</main>