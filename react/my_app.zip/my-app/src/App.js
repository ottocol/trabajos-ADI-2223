import './App.css';
import { Routes, Route } from 'react-router-dom';
import Rutas from './routes';
import ListaProductos from './Productos'

function App() {
  return (
  <div>
    <Routes>
      <Route path = "/" element={<Rutas/>}>
        <Route path = "/listaProductos" element={<ListaProductos/>} />
      </Route>
    </Routes>
  </div>
  );
}



export default App;
