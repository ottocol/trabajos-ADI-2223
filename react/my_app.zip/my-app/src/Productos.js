import './App.css';
import PrductList from './ProductList';

function Productos() {
  return (
    <div>
    <PrductList />
    </div>
  );
}



export default Productos;