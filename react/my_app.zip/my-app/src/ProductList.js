import React from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

class ProductList extends React.Component {

    constructor(props) {
      super(props);
      this.state = {
          productos: []
      };
    }
  
    componentDidMount(){
      axios.get('http://localhost:3001/productos/todos')
        .then(response => {
          this.setState({ productos: response.data });
        })
        .catch(error => {
          console.log(error);
        });
    }
  
    render() {
      return (
        <ul className="list-group">
            <table className="table">
        <thead>
            <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            </tr>
        </thead>
        <tbody>
            {this.state.productos.map(producto => (
            <tr key={producto.id}>
                    <td>{producto.id}</td>
                    <td>{producto.nombre}</td>
                    <td>{producto.descripcion}</td>
            </tr> 
            ))}
        </tbody>
        </table>
      </ul>
      );
    }
  }

  export default ProductList;